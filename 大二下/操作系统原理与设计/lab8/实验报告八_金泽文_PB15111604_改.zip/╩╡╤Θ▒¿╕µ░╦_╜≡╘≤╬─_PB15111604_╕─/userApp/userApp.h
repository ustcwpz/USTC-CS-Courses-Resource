#ifndef __USER_APP_H__
#define __USER_APP_H__

//=======APP, user should define this==================================
#define USER_TASK_NUM 4   // init + myTSK0-2

#endif
