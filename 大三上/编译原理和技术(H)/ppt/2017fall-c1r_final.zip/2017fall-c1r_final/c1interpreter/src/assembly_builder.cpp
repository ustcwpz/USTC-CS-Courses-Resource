
#include "assembly_builder.h"

#include <vector>

using namespace llvm;
using namespace c1_recognizer::syntax_tree;

void assembly_builder::visit(assembly &node)
{
}

void assembly_builder::visit(func_def_syntax &node)
{
}

void assembly_builder::visit(cond_syntax &node)
{
}

void assembly_builder::visit(binop_expr_syntax &node)
{
}

void assembly_builder::visit(unaryop_expr_syntax &node)
{
}

void assembly_builder::visit(lval_syntax &node)
{
}

void assembly_builder::visit(literal_syntax &node)
{
}

void assembly_builder::visit(var_def_stmt_syntax &node)
{
}

void assembly_builder::visit(assign_stmt_syntax &node)
{
}

void assembly_builder::visit(func_call_stmt_syntax &node)
{
}

void assembly_builder::visit(block_syntax &node)
{
}

void assembly_builder::visit(if_stmt_syntax &node)
{
}

void assembly_builder::visit(while_stmt_syntax &node)
{
}

void assembly_builder::visit(empty_stmt_syntax &node)
{
}
