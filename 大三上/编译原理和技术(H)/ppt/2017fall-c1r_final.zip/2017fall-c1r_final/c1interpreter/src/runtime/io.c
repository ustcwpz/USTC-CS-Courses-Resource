
#include <stdio.h>
#include "io.h"

void input(int *i)
{
    scanf("%d", i);
}

void output(int *i)
{
    printf("%d\n", *i);
}
