
#ifndef _C1_RUNTIME__IO_H
#define _C1_RUNTIME__IO_H

#ifdef __cplusplus
extern "C" {
#endif

void input(int *);
void output(int *);

#ifdef __cplusplus
}
#endif

#endif
